
const input = document.getElementById("speedInput");
const status = document.getElementById("status");

async function setSpeed(factor) {
  status.textContent = "doing sumthing i dont even know🥹🤞";

  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });

    if (!tab?.id || !tab.url) {
      throw new Error("not to bother u but i think u to have open slowroads?");
    }

    const url = new URL(tab.url);

    if (
      url.hostname !== "slowroads.io" &&
      url.hostname !== "www.slowroads.io"
    ) {
      throw new Error("just open https://slowroads.io 😭");
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: (value) => {
        const keys = [
          "settings_Vehicle",
          "settings_Gameplay"
        ];

        const changed = [];

        for (const key of keys) {
          const raw = localStorage.getItem(key);
          if (!raw) continue;

          const settings = JSON.parse(raw);
          settings.speedFactor = value;
          localStorage.setItem(key, JSON.stringify(settings));
          changed.push(key);
        }

        return {
          changed,
          vehicle: localStorage.getItem("settings_Vehicle")
        };
      },
      args: [factor]
    });

    const result = results?.[0]?.result;

    if (!result?.changed?.length) {
      throw new Error(
        "didnt find settings maybe try restarting da game?"
      );
    }

    status.textContent =
    `changed to ${factor}. ` +
    `chancged: ${result.changed.join(", ")}. restarting slowroads...`;

    await chrome.tabs.reload(tab.id);
  } catch (error) {
    status.textContent = "error: " + error.message;
  }
}

document.getElementById("setSpeed").addEventListener("click", () => {
  const value = Number(input.value);

  if (
    input.value.trim() === "" ||
    !Number.isFinite(value) ||
    value < 1 ||
    value > 1000
  ) {
    status.textContent = "type a number from 1 to 1000 😭";
    return;
  }

  if (value >= 100) {
    const confirmed = confirm(
      "bestie this might crash the game 😭🤞\n" +
      "high speed factors can break physics or road generation.\n\n" +
      "try it anyway?"
    );

    if (!confirmed) {
      status.textContent = "crash avoided. we live another day 🫡";
      return;
    }
  }

  setSpeed(value);
});

document.getElementById("resetSpeed").addEventListener("click", () => {
  input.value = "1";
  setSpeed(1);
});
